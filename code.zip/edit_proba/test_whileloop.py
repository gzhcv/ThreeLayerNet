import tensorflow as tf
from tensorflow.python.ops import tensor_array_ops
import os

gpu_idex = '5'
os.environ['CUDA_VISIBLE_DEVICES'] = gpu_idex
gpu_options = tf.GPUOptions(allow_growth=True)

t1 = tf.constant(1)
t2 = tf.constant(5)
iters = tf.constant(2)
row = tensor_array_ops.TensorArray(
    dtype=tf.float32,
    size=3,
    dynamic_size=False,
    clear_after_read=False,
    element_shape=[2])

def cond(i, row):
    return tf.less(i, iters)


def body(i, row):
    def f1():
        out = tf.constant(
            1., tf.float32,
            [2])
        row_update = row.write(i, out)

        return i + 1, row_update

    def f2():
        out = row.read(i - 1)+ 1
        row_update = row.write(i, out)

        return i + 1, row_update

    i, row_update = tf.cond(tf.equal(i, 0),
                            f1,
                            f2)

    return [i, row_update]

res = tf.while_loop(cond, body, [0, row])
val = res[1].read(0)

with tf.device('/gpu:' + gpu_idex):
    config = tf.ConfigProto(allow_soft_placement=True, gpu_options=gpu_options)
    with tf.Session(config=config) as sess:
        train_writer = tf.summary.FileWriter('log_dir/test', sess.graph)
        print(sess.run(val))
        print(sess.run(res[1].read(1)))