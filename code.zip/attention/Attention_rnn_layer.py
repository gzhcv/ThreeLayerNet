import numpy as np
from keras import backend as K
from keras.layers import LSTM
import tensorflow as tf
import pdb


class AttentionRNN(LSTM):

    """AttentionRNN mechanism for LSTM layer"""

    def __init__(self, output_dim, batch_size, fv_dim, *args, **kwargs):
        self.fv_dim = fv_dim
        self.batch_size = batch_size
        super(AttentionRNN, self).__init__(output_dim, *args, **kwargs)

    def build(self, input_shape):
        fv_dim = self.fv_dim
        out_dim = self.output_dim
        rnn_input_shape = list(input_shape[:])

        super(AttentionRNN, self).build(rnn_input_shape)
        self.Wah = self.init([out_dim, fv_dim], name='{}_att_Wah'.format(self.name))
        self.Waa = self.init([fv_dim, fv_dim], name='{}_att_Waa'.format(self.name))
        self.V = self.init([fv_dim, 1], name='{}_att_V'.format(self.name))
        # self.B = self.init([fv_dim], name='{}_B'.format(self.name))
        self.trainable_weights.extend([self.Wah, self.Waa, self.V])
        # self.non_trainable_weights = [self.V]
        # self.non_trainable_weights[0].eval(K.get_session()) # why?


    def step(self, x, states):
        x = K.reshape(x, (self.batch_size, -1, self.fv_dim))       # x是输入input
        h = states[0]                                              # lstm当前time-step的隐层状态h

        p1 = K.dot(h, self.Wah)            
        p2 = K.dot(x, self.Waa)
        e = K.tanh(K.expand_dims(p1, dim=1) + p2)                  # [batch  num_steps  fv_dim]     expand_dim [batch  out_dim]  ---> [batch 192  out_dim]
        e = K.dot(e, self.V)                                       # [batch  num_steps  1]
        e = K.reshape(e, (self.batch_size, -1))                    # 去掉维度是1的轴[1]   ---> [batch  num_steps]
        # print('e')
        # print(e.get_shape())
        sums = K.sum(K.exp(e), axis=-1, keepdims=True)             # [batch  1]
        # print('sums')     
        # print(sums.get_shape())                      
        alphas = K.exp(e)/sums                                     # 归一化 权重 [batch  num_steps]
        # print('alpha')  
        # print(alphas.get_shape())                     
        z = K.sum(K.expand_dims(alphas, dim=2)*x, axis=1)          # 对输入x进行加权，并送入lstm作为下一个time-step的输入   z--->ã€batchï¼?1ï¼?fv_dimã€?        print('z')
        print(z.get_shape())

        # p1 = K.dot(h, self.Wah)
        # p2 = K.dot(x, self.Waa)
        # e = K.tanh(K.expand_dims(p1, dim=1) + p2) + self.B 
        # e = K.dot(e, self.V)                          # [batch  num_steps  1]
        # print(e.get_shape())
        # e = K.reshape(e, (32, -1))
        # print(e.get_shape())
        # sums = K.sum(K.exp(e), axis=-1, keepdims=True) 
        # print('sums')     
        # print(sums.get_shape())
        # alphas = K.exp(e)/sums    
        # print('alpha')  
        # print(alphas.get_shape())
        # z = K.sum(x*K.expand_dims(alphas, dim=2), axis=1)   
        # print('z')
        # print(z.get_shape())

        return super(AttentionRNN, self).step(z, states)

    def get_config(self):
        config = {'fv_dim': self.fv_dim}
        base_config = super(AttentionRNN, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))
