import datetime
import logging
import os
import time
import sys

import numpy as np
from compiler.ast import flatten
import tensorflow as tf
import pdb

import BahdAttention
import LuongAttention
import Bahd_PosEmbeed
import utils
import helper

import matplotlib.pyplot as plt

FLAGS = utils.FLAGS

os.environ['CUDA_VISIBLE_DEVICES'] = FLAGS.gpu_idex
gpu_options = tf.GPUOptions(allow_growth=True)
PAD = 0
W = 1
EOS = 0
GO = 0

logger = logging.getLogger('Traing for OCR using CNN+' + FLAGS.model + '+CTC')
logger.setLevel(logging.INFO)


def demo_test(a, b):
    a = np.array(a)
    # max_indx=np.argmax(a)#max value index
    # min_indx=np.argmin(a)#min value index
    plt.plot(a, 'r-o')
    # plt.plot(max_indx,a[max_indx],'ks')
    # show_max='epoch:'+str(b[max_indx])+'  acc:'+str(a[max_indx])
    # plt.annotate(show_max,xytext=(max_indx,a[max_indx]),xy=(max_indx,a[max_indx]))
    # plt.plot(min_indx,a[min_indx],'gs')
    plt.savefig(FLAGS.log_dir + '.png')
    plt.close(0)


def get_decoder_input_and_output(labels, char_pos):
    batch_length_y = np.array([len(yi) for yi in labels]) + 1

    batch_max_length_y = np.max(batch_length_y)

    batch_data_y = []
    batch_char_pos = []
    for i in range(FLAGS.batch_size):
        sample_y = labels[i]
        sample_char_pos = flatten(char_pos[i])
        sample_y = np.r_[sample_y, [EOS], [PAD] * (batch_max_length_y - batch_length_y[i])]
        sample_char_pos = np.r_[sample_char_pos, [W] * (batch_max_length_y - batch_length_y[i]) * 3]
        batch_data_y.append(sample_y)
        batch_char_pos.append(sample_char_pos)

    batch_data_y = np.array(batch_data_y, dtype=np.int32)
    batch_char_pos = np.array(batch_char_pos, dtype=np.float32)
    go_ids = np.c_[np.zeros([FLAGS.batch_size, 1], dtype=np.int32) + GO, batch_data_y]

    return go_ids[:, :-1], go_ids[:, 1:], batch_char_pos, batch_length_y


def train(train_dir=None, val_dir=None, mode='train'):
    if FLAGS.model == 'Bahd':
        model = BahdAttention.LSTMOCR(mode)
    elif FLAGS.model == 'Luong':
        model = LuongAttention.LSTMOCR(mode)
    elif FLAGS.model == 'Bahd_pos_emd':
        model = Bahd_PosEmbeed.LSTMOCR(mode)
    else:
        print("no such model")
        sys.exit()
    model.build_graph()

    print('loading train data, please wait---------------------')
    train_feeder = utils.DataIterator(data_dir=train_dir)
    print('get image: ', train_feeder.size)

    print('loading validation data, please wait---------------------')
    val_feeder = utils.DataIterator(data_dir=val_dir, istrain=False)
    print('get image: ', val_feeder.size)

    num_train_samples = train_feeder.size  # 100000
    num_batches_per_epoch = int(num_train_samples / FLAGS.batch_size)  # example: 100000/100

    num_val_samples = val_feeder.size
    num_batches_per_epoch_val = int(num_val_samples / FLAGS.batch_size)  # example: 10000/100
    shuffle_idx_val = np.random.permutation(num_val_samples)

    with tf.device('/gpu:' + FLAGS.gpu_idex):
        config = tf.ConfigProto(allow_soft_placement=True, gpu_options=gpu_options)
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())

            saver = tf.train.Saver(tf.global_variables(), max_to_keep=100)
            train_writer = tf.summary.FileWriter(FLAGS.log_dir + '/train', sess.graph)
            if FLAGS.restore:
                ckpt = tf.train.latest_checkpoint(FLAGS.checkpoint_dir)
                if ckpt:
                    # the global_step will restore sa well
                    saver.restore(sess, ckpt)
                    print('restore from the checkpoint{0}'.format(ckpt))

            print('=============================begin training=============================')
            accuracy_res = []
            epoch_res = []
            tmp_max = 0
            tmp_epoch = 0
            for cur_epoch in range(FLAGS.num_epochs):
                shuffle_idx = np.random.permutation(num_train_samples)
                train_cost = 0
                train_align_cost = 0
                start_time = time.time()
                batch_time = time.time()

                # the tracing part
                for cur_batch in range(num_batches_per_epoch):
                    if (cur_batch + 1) % 100 == 0:
                        print('batch', cur_batch, ': time', time.time() - batch_time)
                    batch_time = time.time()
                    indexs = [shuffle_idx[i % num_train_samples] for i in
                              range(cur_batch * FLAGS.batch_size, (cur_batch + 1) * FLAGS.batch_size)]
                    batch_inputs, batch_seq_len, batch_labels, batch_char_pos = \
                        train_feeder.input_index_generate_batch(indexs)

                    decoder_inputs, decoder_targets, char_pos_target, decoder_length = \
                        get_decoder_input_and_output(batch_labels, batch_char_pos)
                    # batch_inputs,batch_seq_len,batch_labels=utils.gen_batch(FLAGS.batch_size)

                    feed = {model.inputs: batch_inputs,
                            model.decoder_inputs: decoder_inputs,
                            model.decoder_targets: decoder_targets,
                            model.char_pos: char_pos_target,
                            model.decoder_length: decoder_length,
                            model.seq_len: batch_seq_len}

                    # if summary is needed
                    # batch_cost,step,train_summary,_ = sess.run([cost,global_step,merged_summay,optimizer],feed)
                    # pdb.set_trace()

                    summary_str, batch_cost, batch_align_cost, step, _ = \
                        sess.run([model.merged_summay, model.loss, model.char_loss, model.global_step,
                                  model.train_op], feed)

                    # calculate the cost
                    train_cost += batch_cost * FLAGS.batch_size
                    train_align_cost += batch_align_cost * FLAGS.batch_size
                    train_writer.add_summary(summary_str, step)

                    # save the checkpoint
                    if step % FLAGS.save_steps == 1:
                        if not os.path.isdir(FLAGS.checkpoint_dir):
                            os.mkdir(FLAGS.checkpoint_dir)
                        logger.info('save the checkpoint of{0}', format(step))
                        saver.save(sess, os.path.join(FLAGS.checkpoint_dir, 'ocr-model'),
                                   global_step=step)

                    # train_err += the_err * FLAGS.batch_size
                    # do validation
                    if step % FLAGS.validation_steps == 0:
                        acc_batch_total = 0
                        lr = 0
                        for j in range(num_batches_per_epoch_val):
                            indexs_val = [shuffle_idx_val[i % num_val_samples] for i in
                                          range(j * FLAGS.batch_size, (j + 1) * FLAGS.batch_size)]
                            val_inputs, val_seq_len, _, _ = \
                                val_feeder.input_index_generate_batch(indexs_val)
                            val_feed = {model.inputs: val_inputs,
                                        model.seq_len: val_seq_len}

                            dense_decoded, lr = \
                                sess.run([model.dense_decoded, model.lrn_rate],
                                         val_feed)

                            # print the decode result
                            ori_labels = val_feeder.the_label(indexs_val)
                            acc = utils.accuracy_calculation(ori_labels, dense_decoded,
                                                             ignore_value=0, isPrint=True)
                            acc_batch_total += acc
                        accuracy = (acc_batch_total * FLAGS.batch_size) / num_val_samples
                        accuracy_res.append(accuracy)
                        epoch_res.append(cur_epoch)
                        if accuracy > tmp_max:
                            tmp_max = accuracy
                            tmp_epoch = cur_epoch
                        demo_test(accuracy_res, epoch_res)
                        avg_train_cost = train_cost / ((cur_batch + 1) * FLAGS.batch_size)
                        avg_train_align_cost = train_align_cost / ((cur_batch + 1) * FLAGS.batch_size)
                        # train_err /= num_train_samples

                        now = datetime.datetime.now()
                        log = "{}/{} {}:{}:{} Epoch {}/{}, " \
                              "max_accuracy = {:.3f},max_Epoch {},accuracy = {:.3f},acc_batch_total = {:.3f},avg_train_cost = {:.3f}, " \
                              "avg_train_align_cost = {:.3f}, time = {:.3f},lr={:.8f}"
                        print(log.format(now.month, now.day, now.hour, now.minute, now.second,
                                         cur_epoch + 1, FLAGS.num_epochs, tmp_max, tmp_epoch, accuracy, acc_batch_total,
                                         avg_train_cost,
                                         avg_train_align_cost, time.time() - start_time, lr))


def main(_):
    if FLAGS.num_gpus == 0:
        dev = '/cpu:0'
    elif FLAGS.num_gpus == 1:
        dev = '/gpu:' + FLAGS.gpu_idex
    else:
        raise ValueError('Only support 0 or 1 gpu.')

    with tf.device(dev):
        print(dev)
        if FLAGS.mode == 'train':
            train(FLAGS.train_dir, FLAGS.val_dir, FLAGS.mode)


if __name__ == '__main__':
    tf.logging.set_verbosity(tf.logging.INFO)
    print("plese enter model_name,gpu_idex,log_dir at lesast")
    tf.app.run()
