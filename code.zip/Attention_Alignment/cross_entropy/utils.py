import os
import numpy as np
import tensorflow as tf
from skimage import io
from skimage import transform
import multiprocessing
import pdb
import re

# +-* + () + 10 digit + EOS/GO/PAD
num_classes = 26 + 26 + 10 + 1
PAD = 0
EOS = 0
GO = 0

maxPrintLen = 100

tf.app.flags.DEFINE_integer('rhn_steps', 8, 'number of rhn steps')
tf.app.flags.DEFINE_string('checkpoint_dir', './checkpoint_charloss/', 'the checkpoint dir')
tf.app.flags.DEFINE_integer('rnn_layers', 2, 'number of rnn layers')
tf.app.flags.DEFINE_string('gpu_idex', '11', 'index of gpu')
tf.app.flags.DEFINE_string('model', 'Bahd', 'name of the rnn part')
tf.app.flags.DEFINE_string('log_dir', './log/', 'the logging dir')

tf.app.flags.DEFINE_string('infer_dir', './data/infer/', 'the infer data dir')
tf.app.flags.DEFINE_boolean('restore', False, 'whether to restore from the latest checkpoint')
tf.app.flags.DEFINE_float('initial_learning_rate', 1e-3, 'inital lr')
tf.app.flags.DEFINE_integer('image_height', 32, 'image height')
tf.app.flags.DEFINE_integer('image_width', 100, 'image width')
tf.app.flags.DEFINE_integer('image_channel', 1, 'image channels as input')
tf.app.flags.DEFINE_integer('max_stepsize', 50,
                            'max stepsize in lstm, as well as the output channels of last layer in CNN')
tf.app.flags.DEFINE_integer('num_hidden', 256, 'number of hidden units in lstm')
tf.app.flags.DEFINE_integer('num_epochs', 100, 'maximum epochs')
tf.app.flags.DEFINE_integer('batch_size', 128, 'the batch_size')
tf.app.flags.DEFINE_integer('save_steps', 500, 'the step to save checkpoint')
tf.app.flags.DEFINE_integer('validation_steps', 20, 'the step to validation')
tf.app.flags.DEFINE_float('decay_rate', 0.98, 'the lr decay rate')
tf.app.flags.DEFINE_float('beta1', 0.9, 'parameter of adam optimizer beta1')
tf.app.flags.DEFINE_float('beta2', 0.999, 'adam parameter beta2')
tf.app.flags.DEFINE_integer('decay_steps', 10000, 'the lr decay_step for optimizer')
tf.app.flags.DEFINE_float('momentum', 0.9, 'the momentum')

# tf.app.flags.DEFINE_integer("beam_width", 100, 'an argument of beam_search_decode')

tf.app.flags.DEFINE_string('train_dir', '../posinfo_data/', 'the train data dir')
tf.app.flags.DEFINE_string('val_dir', '../posinfo_data/', 'the val data dir')
tf.app.flags.DEFINE_string('data_dir', '../posinfo_data/', 'the data dir')

tf.app.flags.DEFINE_string('mode', 'train', 'train, val or infer')
tf.app.flags.DEFINE_integer('num_gpus', 1, 'num of gpus')

FLAGS = tf.app.flags.FLAGS

# num_batches_per_epoch = int(num_train_samples/FLAGS.batch_size)

encode_maps = {}
decode_maps = {}

char_dict = {}
word_dict = {}


def char_encode():
    with open("./codedict_62.txt") as f:
        i = 1
        for line in f.readlines():
            line = line.split(' ')
            # line[1] = int(line[1])

            encode_maps[line[0]] = i
            decode_maps[i] = line[0]
            i += 1

    encode_maps[''] = 0
    decode_maps[0] = ''


def file2list(file_path):
    info = []
    with open(file_path) as f:
        all_line = f.read().splitlines()
        i = 0
        for line in all_line:
            if not len(line):
                i += 1
                continue
            if line[0].isalpha():
                info.append(line)
                info.append(all_line[i - 1])
            i += 1
    return info


def read_label():
    for root, sub_folder, file_list in os.walk(FLAGS.data_dir):
        if root.split('/')[-1] == 'txt-char':
            for file_name in file_list:
                file_path = os.path.join(root, file_name)
                file_name = file_name.split('.')[0]
                char_dict[file_name] = file2list(file_path)

        elif root.split('/')[-1] == 'txt-word':
            for file_name in file_list:
                file_path = os.path.join(root, file_name)
                file_name = file_name.split('.')[0]
                word_dict[file_name] = file2list(file_path)


char_encode()
read_label()


class DataIterator:
    def __init__(self, data_dir, istrain=True):
        self.image = []
        self.labels = []
        self.char_pos = []
        if istrain:
            i = 0
            for root, sub_folder, file_list in os.walk(data_dir):
                if root.split('/')[-1] == 'pictures':
                    for file_name in file_list:
                        i += 1
                        if i < 1100:
                            self.read_image_and_label(root, file_name)
                            if i % 5 == 0:
                                print(str(i) + ' images loaded')

        else:
            i = 0
            for root, sub_folder, file_list in os.walk(data_dir):
                if root.split('/')[-1] == 'pictures':
                    for file_name in file_list:
                        i += 1
                        if i >= 1100:
                            self.read_image_and_label(root, file_name)

    @property
    def size(self):
        return len(self.labels)

    def read_image_and_label(self, root, file_name):
        image_path = os.path.join(root, file_name)
        file_name = file_name.split('.')[0]
        char_info = char_dict[file_name]
        word_info = word_dict[file_name]
        word_num = len(word_info) / 2
        char_num = len(char_info) / 2

        def compute_center_point(point_str):
            point_str = point_str.split(',')
            num_point = len(point_str) / 2
            col_all = [int(point_str[2 * i]) for i in range(num_point)]
            row_all = [int(point_str[2 * i + 1]) for i in range(num_point)]

            return sum(col_all) / num_point, sum(row_all) / num_point

        def compute_bound(point_str):
            point_str = point_str.split(',')
            num_point = len(point_str) / 2
            col_all = [int(point_str[2 * i]) for i in range(num_point)]
            row_all = [int(point_str[2 * i + 1]) for i in range(num_point)]

            return min(col_all), max(col_all), min(row_all), max(row_all)

        def compute_width(point_str):
            column_min, column_max, _, _ = compute_bound(point_str)

            return column_max - column_min

        if os.path.exists(image_path):
            im = io.imread(image_path, as_grey=True)
            for item_w in range(word_num):
                code = []
                char_pos = []
                numchar_in_word = 0
                flag_width_char = False
                word = re.sub('[^a-zA-Z]', '', word_info[2 * item_w])
                col_min, col_max, row_min, row_max = compute_bound(word_info[2 * item_w + 1])
                width = col_max - col_min
                height = row_max - row_min
                w_scale_ratio = FLAGS.image_width / float(width)
                h_scale_ratio = FLAGS.image_height / float(height)

                for item_c in range(char_num):
                    if char_info[2 * item_c].isalpha():
                        center_col, center_row = compute_center_point(char_info[2 * item_c + 1])
                        c_col_min, c_col_max, c_row_min, c_row_max = compute_bound(char_info[2 * item_c + 1])
                        if col_min <= center_col <= col_max and row_min <= center_row <= row_max \
                                and char_info[2 * item_c] in word:
                            # if col_min <= c_col_min and c_col_max <= col_max and \
                            #   row_min <= c_row_min and c_row_max <= row_max:
                            code.append(char_info[2 * item_c])
                            center_col_new = (center_col - col_min) * w_scale_ratio
                            center_row_new = (center_row - row_min) * h_scale_ratio
                            width_char = compute_width(char_info[2 * item_c + 1]) * w_scale_ratio
                            # if width_char < 5 or width_char > 90:
                            if width_char == 0:
                                print(file_name)
                                flag_width_char = True
                                break
                            char_pos.append([center_col_new, center_row_new, width_char])
                            numchar_in_word += 1

                # if numchar_in_word < 2 or width < 20 or flag_width_char:
                code = ''.join(code)
                if flag_width_char or code != word:
                    continue
                im_crop = im[row_min:row_max, col_min:col_max]
                im_crop = transform.resize(im_crop, (FLAGS.image_height, FLAGS.image_width, FLAGS.image_channel))
                im_crop = im_crop.astype('float32')
                self.image.append(im_crop)
                code = [encode_maps[c] for c in code]
                self.labels.append(code)
                self.char_pos.append(char_pos)

    def the_label(self, indexs):
        labels = []
        for i in indexs:
            labels.append(self.labels[i])

        return labels

    def input_index_generate_batch(self, index=None):
        if index:
            image_batch = [self.image[i] for i in index]
            label_batch = [self.labels[i] for i in index]
            char_pos_batch = [self.char_pos[i] for i in index]
        else:
            image_batch = self.image
            label_batch = self.labels
            char_pos_batch = self.char_pos

        def get_input_lens(sequences):
            # 64 is the output channels of the last layer of CNN
            lengths = np.asarray([FLAGS.max_stepsize for _ in sequences], dtype=np.int64)

            return sequences, lengths

        batch_inputs, batch_seq_len = get_input_lens(np.array(image_batch))
        batch_labels = label_batch

        return batch_inputs, batch_seq_len, batch_labels, char_pos_batch


def accuracy_calculation(original_seq, decoded_seq, ignore_value=0, isPrint=False):
    if len(original_seq) != len(decoded_seq):
        print('original lengths is different from the decoded_seq, please check again')
        return 0
    count = 0

    with open('./test.txt', 'w') as f:

        for i, origin_label in enumerate(original_seq):
            decoded_label = [j for j in decoded_seq[i] if j != ignore_value]

            # num_char = 0
            # for i in range(len(decoded_label)):
            #    if decoded_label[i] == 0:
            #        num_char = i+1
            # decoded_label = decoded_label[:num_char]

            if isPrint and i < maxPrintLen:
                # print('seq{0:4d}: origin: {1} decoded:{2}'.format(i, origin_label, decoded_label))

                f.write(str(origin_label) + '\t' + str(decoded_label))
                f.write('\n')

            if origin_label == decoded_label:
                count += 1

    return count * 1.0 / len(original_seq)


def eval_expression(encoded_list):
    """
    :param encoded_list:
    :return:
    """

    eval_rs = []
    for item in encoded_list:
        try:
            rs = str(eval(item))
            eval_rs.append(rs)
        except:
            eval_rs.append(item)
            continue

    with open('./result.txt') as f:
        for ith in range(len(encoded_list)):
            f.write(encoded_list[ith] + ' ' + eval_rs[ith] + '\n')

    return eval_rs
