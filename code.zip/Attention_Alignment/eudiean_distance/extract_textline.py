import os
import numpy as np
import tensorflow as tf
from skimage import io
from skimage import transform
import re
from skimage import draw


# +-* + () + 10 digit + EOS/GO/PAD
num_classes = 26 + 26 + 10 + 1
PAD = 0
EOS = 0
GO = 0

tf.app.flags.DEFINE_integer('image_height', 32, 'image height')
tf.app.flags.DEFINE_integer('image_width', 100, 'image width')
tf.app.flags.DEFINE_integer('image_channel', 3, 'image channels as input')

tf.app.flags.DEFINE_string('train_dir', '../posinfo_data/', 'the train data dir')
tf.app.flags.DEFINE_string('val_dir', '../posinfo_data/', 'the val data dir')
tf.app.flags.DEFINE_string('data_dir', '../posinfo_data/', 'the data dir')
tf.app.flags.DEFINE_string('save_dir', '../posinfo_charflag/', 'the dir to save image')

FLAGS = tf.app.flags.FLAGS

encode_maps = {}
decode_maps = {}

char_dict = {}
word_dict = {}

def char_encode():
    with open("./codedict_62.txt") as f:
        i = 1
        for line in f.readlines():
            line = line.split(' ')
            # line[1] = int(line[1])

            encode_maps[line[0]] = i
            decode_maps[i] = line[0]
            i += 1

    encode_maps[''] = 0
    decode_maps[0] = ''

def file2list(file_path):
    info = []
    with open(file_path) as f:
        all_line = f.read().splitlines()
        i = 0
        for line in all_line:
            if not len(line):
                i += 1
                continue
            if line[0].isalpha():
                info.append(line)
                info.append(all_line[i - 1])
            i += 1
    return info


def read_label():
    for root, sub_folder, file_list in os.walk(FLAGS.data_dir):
        if root.split('/')[-1] == 'txt-char':
            for file_name in file_list:
                file_path = os.path.join(root, file_name)
                file_name = file_name.split('.')[0]
                char_dict[file_name] = file2list(file_path)

        elif root.split('/')[-1] == 'txt-word':
            for file_name in file_list:
                file_path = os.path.join(root, file_name)
                file_name = file_name.split('.')[0]
                word_dict[file_name] = file2list(file_path)


char_encode()
read_label()


class DataIterator:
    def __init__(self, data_dir, istrain=True):
        self.image = []
        self.labels = []
        self.char_pos = []
        if not os.path.exists(FLAGS.save_dir):
            os.mkdir(FLAGS.save_dir)

        i = 0
        for root, sub_folder, file_list in os.walk(data_dir):
            if root.split('/')[-1] == 'pictures':
                for file_name in file_list:
                    i += 1
                    if i < 2000:
                        self.read_image_and_label(root, file_name)
                        if i % 5 == 0:
                            print(str(i) + ' images processed')

    @property
    def size(self):
        return len(self.labels)

    def read_image_and_label(self, root, file_name):
        image_path = os.path.join(root, file_name)
        file_name = file_name.split('.')[0]
        char_info = char_dict[file_name]
        word_info = word_dict[file_name]
        word_num = len(word_info) / 2
        char_num = len(char_info) / 2

        def compute_center_point(point_str):
            point_str = point_str.split(',')
            num_point = len(point_str) / 2
            col_all = [int(point_str[2 * i]) for i in range(num_point)]
            row_all = [int(point_str[2 * i + 1]) for i in range(num_point)]

            return sum(col_all) / num_point, sum(row_all) / num_point

        def compute_bound(point_str):
            point_str = point_str.split(',')
            num_point = len(point_str) / 2
            col_all = [int(point_str[2 * i]) for i in range(num_point)]
            row_all = [int(point_str[2 * i + 1]) for i in range(num_point)]

            return min(col_all), max(col_all), min(row_all), max(row_all)

        def compute_width(point_str):
            column_min, column_max, _, _ = compute_bound(point_str)

            return column_max - column_min

        if os.path.exists(image_path):
            im = io.imread(image_path, as_grey=False)


            for item_w in range(word_num):
                code = []
                char_pos = []
                numchar_in_word = 0
                flag_width_char = False
                word = re.sub('[^a-zA-Z]', '', word_info[2 * item_w])
                col_min, col_max, row_min, row_max = compute_bound(word_info[2 * item_w + 1])
                width = col_max - col_min
                height = row_max - row_min
                w_scale_ratio = FLAGS.image_width / float(width)
                h_scale_ratio = FLAGS.image_height / float(height)

                im_crop = im[row_min:row_max, col_min:col_max, :]
                im_crop = transform.resize(im_crop, (FLAGS.image_height, FLAGS.image_width, FLAGS.image_channel))
                im_crop = im_crop.astype('float32')

                for item_c in range(char_num):
                    if char_info[2 * item_c].isalpha():
                        center_col, center_row = compute_center_point(char_info[2 * item_c + 1])
                        c_col_min, c_col_max, c_row_min, c_row_max = compute_bound(char_info[2 * item_c + 1])
                        if col_min <= center_col <= col_max and row_min <= center_row <= row_max \
                                and char_info[2 * item_c] in word:
                        #if col_min <= c_col_min and c_col_max <= col_max and \
                        #   row_min <= c_row_min and c_row_max <= row_max:
                            code.append(char_info[2 * item_c])
                            center_col_new = (center_col - col_min) * w_scale_ratio
                            center_row_new = (center_row - row_min) * h_scale_ratio
                            width_char = compute_width(char_info[2 * item_c + 1]) * w_scale_ratio
                            #if width_char < 5 or width_char > 90:
                            if width_char == 0:
                                print(file_name)
                                flag_width_char = True
                                break
                            char_pos.append([center_col_new, center_row_new, width_char])
                            numchar_in_word += 1
                            rr, cc = draw.circle(center_row_new, center_col_new, 2)
                            im_crop[rr, cc, 0] = 0
                            im_crop[rr, cc, 1] = 1
                            im_crop[rr, cc, 2] = 0



                #if numchar_in_word < 2 or width < 20 or flag_width_char:
                code = ''.join(code)
                if flag_width_char or code != word:
                    continue

                save_filename = os.path.join(FLAGS.save_dir, file_name+'_'+code+'.jpg')
                io.imsave(save_filename, im_crop)
                self.image.append(im_crop)
                self.labels.append(code)
                self.char_pos.append(char_pos)


if __name__ == '__main__':
    DataIterator(FLAGS.train_dir)

