# Random-Forest
简单的随机森林算法实现
<br>
直接运行random_forest_example.py即可<br>
<br>



源码讲解
------
网址中附有源码讲解以及我学习随机森林中查看的最容易理解的资料
http://www.dmlearning.cn/single/e819e9120dca41609da49f44c87ac7be.html<br>
<br>
<br>
![image](https://github.com/RRdmlearning/Random-Forest/blob/master/ran.png)
