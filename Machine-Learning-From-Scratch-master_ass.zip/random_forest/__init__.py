# -*- coding: utf-8 -*-

from .random_forest_model import *
