# Decision-Tree
*  简单的回归决策树实现
*  简单的分类决策树实现
<br>
直接运行decision_tree_classifier_example.py 或 decision_tree_regressor_example.py即可<br>
<br>



源码讲解
------
网址中附有源码讲解以及我学习决策树中查看的最容易理解的资料
http://www.dmlearning.cn/single/c5f5c23878b04500a9ed74cf0e6e07bf.html<br>
<br>
<br>
![image](https://github.com/RRdmlearning/Random-Forest/blob/master/des22.png)
